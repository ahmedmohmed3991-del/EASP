"""
EASP AI Service - Phase 0

Python + FastAPI infrastructure entry point.

Scope for Phase 0: a single health endpoint that confirms the service is
running and explicitly reports that no AI models are loaded yet.

Explicitly OUT of scope for Phase 0:
RawNet2 (voice deepfake detection), Faster-Whisper (speech-to-text),
mBERT (social engineering detection), XGBoost, SHAP, risk engine,
policy engine. These belong to later phases.
"""

import os
from datetime import datetime, timezone

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

SERVICE_NAME = "easp-ai-service"
PHASE = "phase-0"

app = FastAPI(
    title="EASP AI Service",
    description="Enterprise AI Security Platform - AI Microservice (Phase 0: infrastructure only)",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class HealthResponse(BaseModel):
    status: str
    service: str
    phase: str
    models_loaded: bool
    models: list[str]
    timestamp: str


@app.get("/", response_model=dict)
def root():
    return {
        "service": SERVICE_NAME,
        "phase": PHASE,
        "message": "EASP AI Service is running.",
    }


@app.get("/health", response_model=HealthResponse)
def health():
    return HealthResponse(
        status="ok",
        service=SERVICE_NAME,
        phase=PHASE,
        models_loaded=False,
        models=[],
        timestamp=datetime.now(timezone.utc).isoformat(),
    )


if __name__ == "__main__":
    import uvicorn

    port = int(os.getenv("PORT", "8000"))
    uvicorn.run("app:app", host="0.0.0.0", port=port, reload=False)
