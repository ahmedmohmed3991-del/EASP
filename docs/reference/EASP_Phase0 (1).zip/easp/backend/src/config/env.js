// Centralized environment variable loader for the backend.
// Phase 0: only infrastructure-related variables. No auth secrets yet.

require('dotenv').config();

const env = {
  PORT: process.env.PORT || 5000,
  MONGO_URI: process.env.MONGO_URI || 'mongodb://localhost:27017/easp',
  AI_SERVICE_URL: process.env.AI_SERVICE_URL || 'http://localhost:8000',
  NODE_ENV: process.env.NODE_ENV || 'development'
};

module.exports = env;
