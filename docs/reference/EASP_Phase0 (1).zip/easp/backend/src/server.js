// EASP Backend - Phase 0
// Node.js + Express infrastructure entry point.
// Scope: JSON parsing, CORS, centralized error handling, /health, /health/ai.
// Explicitly OUT of scope for Phase 0: auth, JWT, RBAC, DLP, risk/policy engines.

const express = require('express');
const cors = require('cors');

const env = require('./config/env');
const { connectDB } = require('./config/db');
const healthRoutes = require('./routes/health');
const { notFoundHandler, errorHandler } = require('./middleware/errorHandler');

const app = express();

app.use(cors());
app.use(express.json());

app.use('/health', healthRoutes);

app.get('/', (req, res) => {
  res.status(200).json({
    service: 'easp-backend',
    phase: 'phase-0',
    message: 'EASP Backend is running.'
  });
});

app.use(notFoundHandler);
app.use(errorHandler);

async function start() {
  await connectDB();

  app.listen(env.PORT, () => {
    console.log(`[EASP Backend] Listening on port ${env.PORT} (${env.NODE_ENV})`);
  });
}

start();

module.exports = app;
