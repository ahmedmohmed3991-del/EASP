import React from 'react';
import SystemStatusPage from './pages/SystemStatusPage.jsx';

export default function App() {
  return <SystemStatusPage />;
}
